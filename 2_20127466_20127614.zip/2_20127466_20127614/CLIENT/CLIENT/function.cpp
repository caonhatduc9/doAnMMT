#include<Windows.h>
#include "pch.h"
#include "framework.h"
#include "CLIENT.h"
#include"afxsock.h"
#include"string.h"
#include <string>
#include<vector>
#include<conio.h>
#include<iostream>
#include"function.h"
using namespace std;

int resquest(CSocket& c, string s) {
	int len = s.length();
	c.Send(&len, sizeof(int), 0);
	c.Send(s.c_str(), len, 0);
	return len;
}
char* response(CSocket& c)
{
	char* r;
	int len;
	c.Receive(&len, sizeof(int), 0);
	if (len < 0) {
		r = new char[1];
		strcpy_s(r, 2, "\0");
		return r;
	}
	r = new char[len];
	c.Receive(r, len, 0);
	r[len] = 0;
	return r;
}

string toSTRING(char* str)
{
	string s;
	for (int i = 0; i < strlen(str); i++)
	{
		s.push_back(str[i]);
	}
	return s;
}

int checkDate(string date[])
{
	if (date[0].length() < 2 || date[1].length() < 2 || date[2].length() < 4)return 0;
	if (atoi(date[2].c_str()) > 2021)return 0;
	if (atoi(date[2].c_str()) % 400 == 0 || atoi(date[2].c_str()) % 4 == 0 && atoi(date[2].c_str()) % 100 != 0)
	{
		if (atoi(date[1].c_str()) == 2)
		{
			if (atoi(date[0].c_str()) > 29)return 0;
		}
	}
	if (atoi(date[1].c_str()) == 2)
	{
		if (atoi(date[0].c_str()) > 28)return 0;
	}
	if (atoi(date[1].c_str()) == 1 || atoi(date[1].c_str()) == 3 || atoi(date[1].c_str()) == 5 || atoi(date[1].c_str()) == 7 || atoi(date[1].c_str()) == 8 || atoi(date[1].c_str()) == 10 || atoi(date[1].c_str()) == 12)
	{
		if (atoi(date[0].c_str()) > 31)return 0;
	}
	else if (atoi(date[1].c_str()) == 4 || atoi(date[1].c_str()) == 6 || atoi(date[1].c_str()) == 9 || atoi(date[1].c_str()) == 11)
	{
		if (atoi(date[0].c_str()) > 30)return 0;
	}
	return 1;
}
void nhapNgay(string date[])
{
	int check;
	do
	{
		cout << "\t\t\t\t\Nhap ngay ban muon tra:(dd/mm/yyyy)";
		cout << endl;
		cout << "\t\t\t\t\dd:";
		cin >> date[0];
		cout << "\t\t\t\t\mm:";
		cin >> date[1];
		cout << "\t\t\t\t\yyyy:";
		cin >> date[2];
		check = checkDate(date);
		if (check == 0)
			cout << "\t\t\t\t\Ngay ban nhap sai hoac khong dung dinh dang,vui long nhap lai" << endl;
	} while (check == 0);
}
void nhapLuaChon(int& choice)
{
	int  flag = 0, x;
	string buf;
	do {
		cout << "\n\t\t\t\tNhap lua chon: ";
		cin >> buf;

		if (buf.length() == 1 && buf[0] >= 48 && buf[0] <= 57)
		{
			choice = stoi(buf);
			if (choice == 2 || choice == 1 || choice == 0)
				flag = 1;
		}
		if (flag == 0)
		{
			cout << "\t\t\t\tLua chon khong hop le.";
		}

	} while (flag == 0);
}
void nhapLuaChon1(int& choice)
{
	int  flag = 0, x;
	string buf;
	do {
		cout << "\n\t\t\t\tNhap lua chon: ";
		cin >> buf;

		if (buf.length() == 1 && buf[0] >= 48 && buf[0] <= 57)
		{
			choice = stoi(buf);
			if (choice == 1 || choice == 0)
				flag = 1;
		}
		if (flag == 0)
		{
			cout << "\t\t\t\tLua chon khong hop le.";
		}

	} while (flag == 0);
}
void nhapUser(string signUp[])
{
	int flag = 0;
	string s;
	while (flag == 0)
	{
		flag = 1;
		cout << "\n\t\t\t\tTen dang nhap(phai co it nhat 5 ki tu va khong chua khoang trang): ";
		//cin.ignore();
		getline(cin, signUp[0]);
		s = signUp[0];
		if (s.size() < 5)
		{
			flag = 0;
		}
		for (int i = 0; i < signUp[0].size(); i++)
			if (s[i] == ' ')
			{
				flag = 0;
				break;
			}
		if (flag == 1)
		{
			int flag1 = 0, flag2 = 0;
			while (flag1 == 0 && flag2 == 0)
			{
				cout << "\t\t\t\tMat khau(phai it nhat 5 ki tu): ";
				getline(cin, signUp[1]);
				string ch = signUp[1];
				if (ch.size() >= 5)
				{
					flag1 = 1;
				}
				cout << "\t\t\t\tNhap lai mat khau: ";
				getline(cin, signUp[2]);
				string ch1 = signUp[2];
				if (ch1 == ch && ch1.size() >= 5)
				{
					flag2 = 1;
				}
			}
		}
		else
			cout << "\t\t\t\tTen dang nhap khong hop le";

	}
}
void showData(TIENTE t[17], string inforDate, int check, int capacity)
{
	system("cls");
	GotoXY(37, 15);
	if (check == 0)
	{
		cout << inforDate << endl << endl;
		Sleep(1500);
		system("cls");
	}
	else {
		DrawBoard2();
		GotoXY(8, 2);
		SetTColor(12);
		cout << "Ten";
		GotoXY(20, 2);
		SetTColor(12);

		cout << "Ty gia trung tam";
		GotoXY(46, 2);
		SetTColor(12);

		cout << "Ty gia mua";
		GotoXY(70, 2);
		SetTColor(12);

		cout << "Ty gia ban";
		GotoXY(39, 4);
		SetTColor(12);

		cout << "Tien mat";
		GotoXY(52, 4);
		SetTColor(12);

		cout << "Chuyen khoan";
		int i;
		for (i = 0; i < capacity; i++)
		{
			GotoXY(8, 6 + i);
			cout << t[i].ten;
			GotoXY(27, 6 + i);
			cout << t[i].tyGiaTT;
			GotoXY(40, 6 + i);
			cout << t[i].tyGiaMua.tienMat;
			GotoXY(55, 6 + i);
			cout << t[i].tyGiaMua.chuyenKhoan;
			GotoXY(70, 6 + i);
			cout << t[i].tyGiaBan;
			if (i == 5)
			{
				GotoXY(40, 6 + 1 + i);
				cout << t[i].note;
				i++;
			}
			GotoXY(40, 6 + 1 + i);
			cout << t[i].note;
		}
		GotoXY(84, 4);
		SetTColor(13);
		cout << "Ty gia duoc cap nhat luc: ";
		GotoXY(84, 5);
		cout << inforDate;
		GotoXY(84, 6);
		cout << "#:EUR,USD co menh gia:50,100";
		GotoXY(84, 7);
		cout << "&:EUR,USD co menh gia nho hon 50";
	}
}
void waiting()
{
	system("cls");
	GotoXY(50, 13);
	cout << "waiting";
	Sleep(700);
	GotoXY(57, 13);
	cout << ".";
	Sleep(700);
	GotoXY(58, 13);
	cout << ".";
	Sleep(700);
	GotoXY(59, 13);
	cout << ".";
}
void upCase(string& a)
{
	for (int i = 0; i <= a.size(); i++) {
		if (a[i] >= 97 && a[i] <= 122)
			a[i] = a[i] - 32;
	}
}
string nhapLoaiTien(string nameCurent[])
{
	string c;

	int check = 0;
	do
	{
		cout << "\t\t\tNhap ten tien can tra cuu: ";
		cin >> c;
		upCase(c);
		for (int i = 0; i < 17; i++)
		{
			if (c == nameCurent[i])
			{
				check = 1;
				break;
			}
		}
		if (check == 0)
		{
			cout << "\t\t\tLoai tien ban nhap khong co trong danh sach ngan hang.Hay nhap lai: \n";

		}
	} while (check == 0);
	return c;
}
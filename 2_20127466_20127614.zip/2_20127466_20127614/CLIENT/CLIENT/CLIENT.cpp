// client.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "pch.h"
#include "framework.h"
#include "CLIENT.h"
#include"afxsock.h"
#include"function.h"
#include"decorate.h"
using namespace std;
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// The one and only application object

CWinApp theApp;

using namespace std;


int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;
	FixConsoleWindow();
	HMODULE hModule = ::GetModuleHandle(nullptr);

	if (hModule != NULL)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, NULL, ::GetCommandLine(), 0))
		{
			// TODO: code your application's behavior here.
			_tprintf(_T("Fatal Error: MFC initialization failed\n"));
			nRetCode = 1;
		}
		else
		{
			AfxSocketInit(NULL);
			system("color 71");

			CSocket client;
			client.Create();
			int F = 1;
			//DrawBoard2();
			while (F == 1)
			{
				hcmus();
				string k = "HCMUS:DO AN LAP TRINH SOCKET-20127614-20127466";
				for (int i = 0; i < k.size(); i++)
				{
					GotoXY(i, 0);
					cout << k[i];
				}
				DrawBoard();
				GotoXY(33, 4);
				std::cout << "Vui long nhap dia chi IP de truy cap:";
				char ip[100];
				int id;
				gets_s(ip);
				if ((strlen(ip) >= 0 && strlen(ip) <= 8))
				{
					Sleep(1);
					GotoXY(33, 6);
					cout << "Dia chi IP khong hop le." << endl;
					Sleep(500);
					system("cls");
				}
				else if (client.Connect(CA2W(ip), 8888) == true)
				{
					GotoXY(33, 5);
					std::cout << "Ket noi thanh cong." << endl;
					Sleep(500);
					system("cls");
					F = 0;
				}
				else
				{
					Sleep(1);
					GotoXY(33, 6);
					cout << "Dia chi IP khong hop le." << endl;
					Sleep(500);
					system("cls");
				}
			}

			TIENTE t[17];
			string nameCurent[17] = { "AUD","CAD","CHF", "CNY", "DKK", "EUR","GBP", "HKD","JPY","KRW","LAK","NOK","NZD","SEK","SGD","THB","USD" };
			string s;
			char* r;
			int len, choice, status = 1;

			while (1) {

				DrawBoard1();
				GotoXY(62, 2);
				cout << "MENU";
				GotoXY(60, 4);
				cout << "1-Dang nhap";
				GotoXY(60, 5);
				cout << "2-Dang ky";
				GotoXY(60, 6);
				cout << "0-Thoat";
				cout << endl << endl;
				nhapLuaChon(choice);
				//login
				if (choice == 1)
				{
					s = "sign in";
					resquest(client, s);
					cout << "\t\t\t\tTen dang nhap: ";
					cin.ignore();
					getline(cin, s);
					resquest(client, s);
					cout << "\t\t\t\tMat khau: ";
					getline(cin, s);
					resquest(client, s);
					s = response(client);
					if (s == "\0")
					{
						status = 0; break;
					}
					system("cls");
					if (s == "1")
					{
						while (1)
						{
							SetTColor(2);
							GotoXY(53, 2);
							cout << "TRA CUU";
							DrawBoard1();
							SetTColor(2);
							GotoXY(50, 4);
							cout << "1-Tra cuu theo loai tien te";
							GotoXY(50, 5);
							cout << "2-Tra cuu theo ngay";
							GotoXY(50, 6);
							cout << "0-Thoat";
							cout << endl << endl;
							nhapLuaChon(choice);
							if (choice == 1)
							{
								int check = 0;
								resquest(client, "1");
								s = nhapLoaiTien(nameCurent);
								resquest(client, s);
								waiting();
								s = response(client);
								if (s == "\0")
								{
									status = 0; break;
								}
								if (s == "1")
								{
									check = 1;

									t[0].ten = response(client);
									if (s == "\0")
									{
										status = 0; break;
									}
									t[0].tyGiaTT = response(client);
									t[0].tyGiaMua.tienMat = response(client);
									t[0].tyGiaMua.chuyenKhoan = response(client);
									t[0].tyGiaBan = response(client);
									t[0].note = response(client);

								}
								s = response(client);
								if (s == "\0")
								{
									status = 0; break;
								}

								showData(t, s, check, 1);
								if (check != 0)
								{
									GotoXY(10, 26);
									SetTColor(10);
									cout << "\t  1.Tiep tuc tra cuu" << endl;
									GotoXY(10, 27);
									cout << "\t  0.Thoat" << endl;
									int choiceT;
									nhapLuaChon1(choiceT);
									if (choiceT == 1)
									{
										system("cls");
									}
									else if (choiceT == 0)
									{
										system("cls");
										resquest(client, "0");
										break;
									}
								}
							}
							else if (choice == 2)
							{
								int check = 0;
								resquest(client, "2");
								string date[3];
								nhapNgay(date);
								resquest(client, date[0]);
								resquest(client, date[1]);
								resquest(client, date[2]);
								waiting();
								s = response(client);
								if (s == "\0")
								{
									status = 0; break;
								}
								else if (s == "1")
								{
									check = 1;
									for (int i = 0; i < 17; i++)
									{
										t[i].ten = response(client);
										t[i].tyGiaTT = response(client);
										t[i].tyGiaMua.tienMat = response(client);
										t[i].tyGiaMua.chuyenKhoan = response(client);
										t[i].tyGiaBan = response(client);
										t[i].note = response(client);
									}
								}
								s = response(client);
								if (s == "\0")
								{
									status = 0; break;
								}
								else
								{
									showData(t, s, check, 17);
									if (check != 0)
									{
										GotoXY(10, 26);
										SetTColor(10);
										cout << "\t  1.Tiep tuc tra cuu" << endl;
										GotoXY(10, 27);
										SetTColor(10);

										cout << "\t  0.Thoat" << endl;
										int choiceT;
										nhapLuaChon1(choiceT);
										if (choiceT == 1)
										{
											system("cls");
										}
										else if (choiceT == 0)
										{
											system("cls");
											resquest(client, "0");
											break;
										}
									}

								}
							}

							else if (choice == 0)
							{
								system("cls");
								resquest(client, "0");
								break;
							}

						}
					}
					if (s == "0")
					{
						cout << "\n\t\t\t\tTai khoan khong ton tai hoac mat khau ban nhap khong dung";
						Sleep(1500);
						system("cls");
					}
				}
				//register
				else if (choice == 2)
				{
					s = "sign up";
					resquest(client, s);
					string signUp[3];
					cin.ignore();
					nhapUser(signUp);
					if (signUp[2] == signUp[1])
					{
						resquest(client, "1");
						resquest(client, signUp[0]);
						resquest(client, signUp[1]);
						s = response(client);
						if (s == "\0")
						{
							status = 0; break;
						}
						else if (s == "1")
						{

							cout << "\t\t\t\tDang ky tai khoan thanh cong\n\n";
							Sleep(1500);
							system("cls");
						}

						else if (s == "0")
						{
							cout << "\t\t\t\tThat bai: Ten tai khoan da ton tai\n\n";
							Sleep(1500);
							system("cls");
						}

					}
					else {

						cout << "\t\t\t\tBan can nhap 2 mat khau giong nhau\n\n";
						Sleep(1500);
						system("cls");
						resquest(client, "0");
						s = response(client);
						if (s == "\0")
						{
							status = 0; break;
						}
					}
				}
				//exit 
				else if (choice == 0)
				{
					resquest(client, "exit");
					break;
				}
			}
			client.Close();
			system("cls");
			GotoXY(50, 15);
			system("color 70");
			if (status == 0)
				cout << "Sever khong co tin hieu!!!";
			else
			{

				bye();

			}
			_getch();

		}

	}
	else
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: GetModuleHandle failed\n"));
		nRetCode = 1;
	}
	return nRetCode;
}




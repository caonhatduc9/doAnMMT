#pragma once
#include<Windows.h>
#include "pch.h"
#include "framework.h"
#include "CLIENT.h"
#include"afxsock.h"
#include<string.h>
#include<string>
#include<vector>
#include<conio.h>
#include<iostream>
#include"decorate.h"
using namespace std;
struct MUA {
	string tienMat, chuyenKhoan;
};
struct TIENTE {
	string ten, tyGiaTT, tyGiaBan, note;
	MUA tyGiaMua;
};

int resquest(CSocket& c, string s);
char* response(CSocket& c);
string toSTRING(char* str);
int checkDate(string date[]);
void nhapNgay(string date[]);
void nhapLuaChon(int& choice);
void nhapLuaChon1(int& choice);
void nhapUser(string signUp[]);
void showData(TIENTE t[17], string inforDate, int check, int capacity);
void waiting();
void upCase(string& a);
string nhapLoaiTien(string nameCurent[]);

#define CURL_STATICLIB
#include "framework.h"
#include "resource.h"
#include "pch.h"
#include "secFunction.h"
#include "primeFunction.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#define SIZE 2
#endif

CWinApp theApp;

using namespace std;
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	SetTColor(12);
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(NULL);

	if (hModule != NULL)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, NULL, ::GetCommandLine(), 0))
		{
			// TODO: code your application's behavior here.
			_tprintf(_T("Fatal Error: MFC initialization failed\n"));
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
			AfxSocketInit(NULL);
			//socket sever va client
			CSocket sv;
			CSocket cl1;
			DWORD threadID;
			HANDLE threadStatus;
			//khoi tao socket voi port
			sv.Create(8888);
			cout << "\n\t\t\t\t\tvui long doi sever khoi tao du lieu";
			createDatabase("data.txt");
			thread up(update30, "data.txt");
			up.detach();
			cout << "\n\t\t\t\t\tLang nghe cac clients...  ";
			do {
				sv.Listen();
				if (sv.Accept(cl1))
					cout << "\n\t\t\t\t\t1 client vua ket noi";
				//cnt++;
				//Khoi tao con tro Socket
				SOCKET* hConnected = new SOCKET();
				//Chuyển đỏi CSocket thanh Socket
				*hConnected = cl1.Detach();
				//Khoi tao thread tuong ung voi moi client Connect vao server.
				//Nhu vay moi client se doc lap nhau, khong phai cho doi tung client xu ly rieng
				//cout << cnt;
				threadStatus = CreateThread(NULL, 0, function_cal, hConnected, 0, &threadID);

			} while (1);
		}
	}
	else
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: GetModuleHandle failed\n"));
		nRetCode = 1;
	}
	return nRetCode;
}


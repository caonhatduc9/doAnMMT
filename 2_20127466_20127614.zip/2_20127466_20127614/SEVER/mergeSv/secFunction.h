#ifndef secFunction_h
#define secFunction_h
#include<string>
#include<iostream>
#include "afxsock.h"
using namespace std;
void currentDay(int& day, int& month, int& year);
bool isLeepYear(int nYear);
int dayOfMonth(int nMonth, int nYear);
void yesterday(int& nDay, int& nMonth, int& nYear);
int resquest(CSocket& cs, string s);
char* response(CSocket& c);
void SetTColor(WORD color);
#endif // !secFunction_h

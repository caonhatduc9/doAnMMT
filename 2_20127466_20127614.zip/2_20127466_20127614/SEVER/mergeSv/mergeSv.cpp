// sever.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#define CURL_STATICLIB
#include"pch.h"
#include "framework.h"
#include "mergesv.h"
#include "afxsock.h"
#include"pch.h"
#include<iostream>
#include<fstream>
#include<sstream>
#include<vector>
#include<string>
#include<sstream>
#include<curl/curl.h>
using namespace std;
#ifdef _DEBUG
#define new DEBUG_NEW
#define SIZE 2
#endif

//int cnt = 1;
// The one and only application object

CWinApp theApp;

using namespace std;
struct MUA {
	string tienMat, chuyenKhoan;
};
struct TIENTE {
	string ten, tyGiaTT, tyGiaBan, note;
	MUA tyGiaMua;
};
struct TODAY {
	string d, m, y;
};
struct USER {
	string u, p;
};


//chia qua file chi dung cho ngay thang nam
void currentDay(int& day, int& month, int& year)
{
	time_t now = time(0);
	tm ltm;
	localtime_s(&ltm, &now);
	day = ltm.tm_mday;
	month = ltm.tm_mon + 1;
	year = ltm.tm_year + 1900;
}
bool isLeepYear(int nYear)
{
	if ((nYear % 4 == 0 && nYear % 100 != 0) || nYear % 400 == 0)
	{
		return true;
	}
	return false;
}
int dayOfMonth(int nMonth, int nYear)
{
	int nNumOfDays;

	switch (nMonth)
	{
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		nNumOfDays = 31;
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		nNumOfDays = 30;
		break;
	case 2:
		if (isLeepYear(nYear))
		{
			nNumOfDays = 29;
		}
		else
		{
			nNumOfDays = 28;
		}
		break;
	}

	return nNumOfDays;
}
void yesterday(int& nDay, int& nMonth, int& nYear)
{
	nDay--;
	if (nDay == 0)
	{
		nMonth--;
		if (nMonth == 0)
		{
			nMonth = 12;
			nYear--;
		}
		nDay = dayOfMonth(nMonth, nYear);
	}
}


void cleanData(string data, string name, TIENTE& t)
{
	t.ten = name;
	size_t distance1 = data.find(name) + 27;
	size_t pos1 = data.find(">", distance1 - 2);
	size_t pos2 = data.find("<", pos1);
	size_t numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaTT = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaMua.tienMat = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaMua.chuyenKhoan = data.substr(distance1, numberOfDigit);

	distance1 = distance1 + numberOfDigit + 24;
	pos1 = data.find(">", distance1 - 2);
	pos2 = data.find("<", pos1);
	numberOfDigit = pos2 - pos1 - 1;
	t.tyGiaBan = data.substr(distance1, numberOfDigit);

	if (name == "EUR")
	{
		distance1 = distance1 + numberOfDigit + 98;
		pos1 = data.find(">", distance1 - 2);
		pos2 = data.find("<", pos1);
		numberOfDigit = pos2 - pos1 - 1;
		t.note = data.substr(distance1, numberOfDigit);
		distance1 = distance1 + numberOfDigit + 24;
	}
	if (name == "USD")
	{
		distance1 = distance1 + numberOfDigit + 97;
		pos1 = data.find(">", distance1 - 2);
		pos2 = data.find("<", pos1);
		numberOfDigit = pos2 - pos1 - 1;
		t.note = data.substr(distance1, numberOfDigit);
		distance1 = distance1 + numberOfDigit + 24;
	}
}

static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
	((string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}

bool crawlDataFromWebToFile(string fileName, TIENTE tienTe[], string& data, string url, string nameCurrent[]) {
	CURL* curl;
	CURLcode res;
	string readBuffer;

	curl = curl_easy_init();
	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
		size_t indexStart = readBuffer.find("<body>");
		size_t indexEnd = readBuffer.find("</body>", indexStart);
		data = readBuffer.substr(indexStart, indexEnd - indexStart);

		if (data.find("Không có bảng tỷ giá") == -1)
			return true;
		return false;
	}
}

void createDatabase(string fileName)
{

	TODAY td;
	TIENTE tienTe[17];
	string data;
	int day, month, year;
	currentDay(day, month, year);
	string nameCurent[17] = { "AUD","CAD","CHF", "CNY", "DKK", "EUR","GBP", "HKD",
							"JPY","KRW","LAK","NOK","NZD","SEK","SGD","THB","USD" };
	ofstream f;
	f.open(fileName);
	for (int i = 5; i > 0; i--)
	{
		string url = "https://www.vietinbank.vn/web/home/vn/ty-gia/?theDate=";
		if (day < 10)
			td.d = "0" + to_string(day);
		else
			td.d = to_string(day);
		if (month < 10)
			td.m = "0" + to_string(month);
		else
			td.m = to_string(month);
		td.y = to_string(year);
		url += td.d + "%2F" + td.m + "%2F" + td.y;
		if (crawlDataFromWebToFile("data.txt", tienTe, data, url, nameCurent) == true)
		{

			f << td.d << "|" << td.m << "|" << td.y << "\n";
			for (int i = 0; i < 17; i++)
			{
				cleanData(data, nameCurent[i], tienTe[i]);
				f << tienTe[i].ten << " " << tienTe[i].tyGiaTT << " " << tienTe[i].tyGiaMua.tienMat << " " << tienTe[i].tyGiaMua.chuyenKhoan << " ";
				f << tienTe[i].tyGiaBan << " " << tienTe[i].note;
				f << "\n";
			}
		}
		else
		{
			string inforDate = "EMPTY\n";
			f << inforDate;
		}
		yesterday(day, month, year);
	}
	f.close();
}



//lay thong tin theo ten
bool loadData1(TIENTE& tienTe, string tenTraCuu, string& inforDate)
{
	string d, m, y;
	ifstream f;
	f.open("data.txt");
	string lineInfor, buf;
	int i = 0;

	while (!f.eof())
	{
		getline(f, lineInfor);
		if (lineInfor != "EMPTY") {
			inforDate = lineInfor;
			do {
				getline(f, lineInfor);
				stringstream buf(lineInfor);
				getline(buf, tienTe.ten, ' ');
				getline(buf, tienTe.tyGiaTT, ' ');
				getline(buf, tienTe.tyGiaMua.tienMat, ' ');
				getline(buf, tienTe.tyGiaMua.chuyenKhoan, ' ');
				getline(buf, tienTe.tyGiaBan, ' ');
				getline(buf, tienTe.note, ' ');
			} while (tenTraCuu != tienTe.ten);
			return true;
		}
	}
	f.close();
	return false;
}
//lay thong tin theo ngay
bool loadData2(TIENTE tienTe[], string day, string month, string year)
{
	string d, m, y;
	ifstream f;
	f.open("data.txt");
	string lineInfor, buf;
	int i = 0;
	//	getline(f, lineInfor);

	while (!f.eof())
	{
		getline(f, lineInfor);
		if (lineInfor != "EMPTY") {
			stringstream buf(lineInfor);
			getline(buf, d, '|');
			getline(buf, m, '|');
			getline(buf, y, '\n');
			for (int i = 0; i < 17; i++)
			{
				getline(f, lineInfor);
				stringstream buf(lineInfor);
				getline(buf, tienTe[i].ten, ' ');
				getline(buf, tienTe[i].tyGiaTT, ' ');
				getline(buf, tienTe[i].tyGiaMua.tienMat, ' ');
				getline(buf, tienTe[i].tyGiaMua.chuyenKhoan, ' ');
				getline(buf, tienTe[i].tyGiaBan, ' ');
				getline(buf, tienTe[i].note, ' ');
			}
		}
		if (d == day && m == month && y == year)
		{
			f.close();	return true;
		}
	}
	f.close();
	return false;
}

void GotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
int resquest(CSocket& cs, string s) {
	int len = s.length();
	cs.Send(&len, sizeof(int), 0);
	cs.Send(s.c_str(), len, 0);
	return len;
}
char* response(CSocket& c)
{
	char* r;
	int len;
	c.Receive(&len, sizeof(int), 0);
	if (len < 0) {
		r = new char[1];
		strcpy_s(r, 2, "\0");
		return r;
	}
	r = new char[len];
	c.Receive(r, len, 0);
	r[len] = 0;
	return r;
}
void saveFile(string path, USER user)
{
	ofstream fout;
	fout.open(path, ios::app);
	fout << user.u << " " << user.p << "\n";
	fout.close();
}
bool is_emptyFile(ifstream& pFile)
{
	return pFile.peek() == ifstream::traits_type::eof();
}
int checkUser(string path, USER user, int check)
{
	ifstream fin;
	fin.open(path);

	if (is_emptyFile(fin))
		return 0;
	else
	{
		USER buf;
		while (!fin.eof())
		{
			getline(fin, buf.u, ' ');
			getline(fin, buf.p, '\n');
			if (check == 1)//kierm tra dang ki
			{
				if (user.u == buf.u)
					return 1;
			}
			else
				if (user.u == buf.u && user.p == buf.p)
					return 1;
		}
	}
	return 0;
}

DWORD WINAPI function_cal(LPVOID arg)
{
	SOCKET* hConnected = (SOCKET*)arg;
	CSocket cl1;
	//Chuyen ve lai CSocket
	cl1.Attach(*hConnected);


	string s;
	int len;
	char* r = NULL;
	int check;
	int flag = 1, flag1 = 1;
	while (1)
	{
		//dau tien seve nhan cac tin hieu signin/up exit tu client
		check = 0;
		s = response(cl1);
		if (s == "exit")
		{
			//bao gioừ làm hoàn chỉnh sẽ ghi thêm ip của client
			cout << "\n\t\t\t\t\tclient just close";
			break;
		}
		if (s == "sign in")
		{
			USER u1;
			//nhan pass va user
			u1.u = response(cl1);
			if (u1.u == "\0")
				break;
			u1.p = response(cl1);
			//kiem tra co ton tai trong file chua
			if (checkUser("inforUser.txt", u1, 0) == 1)
			{//phan hoi 1 neu thanh cong, 0 neu that bai
				resquest(cl1, "1");
				cout << "\n\t\t\t\t\tUser: " << u1.u << " has been signed in successfully ";
				//vo phan tra cuu
				while (1)
				{
					s = response(cl1);
					if (s == "\0")
						break;
					if (s == "1")
					{
						string inforDate = "0";
						TIENTE tienTe;
						s = response(cl1);
						if (s == "\0")
							break;
						if (loadData1(tienTe, s, inforDate) == false)
						{
							inforDate = "Khong co thong tin";
							resquest(cl1, "0");
						}
						else {
							resquest(cl1, "1");
							resquest(cl1, tienTe.ten);
							resquest(cl1, tienTe.tyGiaTT);
							resquest(cl1, tienTe.tyGiaMua.tienMat);
							resquest(cl1, tienTe.tyGiaMua.chuyenKhoan);
							resquest(cl1, tienTe.tyGiaBan);
							resquest(cl1, tienTe.note);
						}
						resquest(cl1, inforDate);
					}
					//	tra cuu theo ngay
					else	if (s == "2")
					{
						string inforDate = "0";
						TIENTE tienTe[17];
						string day = response(cl1);
						if (day == "\0")
							break;
						string month = response(cl1);
						string year = response(cl1);

						if (loadData2(tienTe, day, month, year) == false)
						{
							inforDate = "Khong co thong tin bang ty gia ngay: " + day + "|" + month + "|" + year;
							resquest(cl1, "0");
						}
						else {
							resquest(cl1, "1");
							for (int i = 0; i < 17; i++)
							{
								resquest(cl1, tienTe[i].ten);
								resquest(cl1, tienTe[i].tyGiaTT);
								resquest(cl1, tienTe[i].tyGiaMua.tienMat);
								resquest(cl1, tienTe[i].tyGiaMua.chuyenKhoan);
								resquest(cl1, tienTe[i].tyGiaBan);
								resquest(cl1, tienTe[i].note);
							}
							inforDate = "ngay " + day + "/" + month + "/" + year;
						}
						resquest(cl1, inforDate);
					}
					if (s == "0")
						break;
				}//ket thuc tra cuu

			}
			else
				resquest(cl1, "0");
		}
		if (s == "sign up")
		{

			USER u1;
			s = response(cl1);
			if (s == "1")
			{
				u1.u = response(cl1);
				if (u1.u == "\0")
					break;
				u1.p = response(cl1);
				if (checkUser("inforUser.txt", u1, 1) == 0) {
					saveFile("inforUser.txt", u1);
					cout << endl << "\t\t\t\t\tUser: '" << u1.u << "'" << " has already been registered successfully";
					resquest(cl1, "1");
				}
				else resquest(cl1, "0");
			}
			if (s == "0")
				resquest(cl1, "0");
		}

		// 1 la chay, 0 la thoat
	}
	cl1.Close();
	delete hConnected;

	return 0;
	//return 0;
}
void SetTColor(WORD color)
{
	HANDLE hConsoleOutput;
	hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO screen_buffer_info;
	GetConsoleScreenBufferInfo(hConsoleOutput, &screen_buffer_info);
	WORD wAttributes = screen_buffer_info.wAttributes;
	color &= 0x000f;
	wAttributes &= 0xfff0; wAttributes |= color;
	SetConsoleTextAttribute(hConsoleOutput, wAttributes);
}
int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	SetTColor(12);
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(NULL);

	if (hModule != NULL)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, NULL, ::GetCommandLine(), 0))
		{
			// TODO: code your application's behavior here.
			_tprintf(_T("Fatal Error: MFC initialization failed\n"));
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
			AfxSocketInit(NULL);
			//socket sever va client
			CSocket sv;
			CSocket cl1;
			DWORD threadID;
			HANDLE threadStatus;
			//khoi tao socket voi port
			sv.Create(8888);
			cout << "\n\t\t\t\t\tvui long doi sever khoi tao du lieu";
			createDatabase("data.txt");
			cout << "\n\t\t\t\t\twaiting for client  ";
			do {
				sv.Listen();
				if (sv.Accept(cl1))
					cout << "\n\t\t\t\t\tclient conected";
				//cnt++;
				//Khoi tao con tro Socket
				SOCKET* hConnected = new SOCKET();
				//Chuyển đỏi CSocket thanh Socket
				*hConnected = cl1.Detach();
				//Khoi tao thread tuong ung voi moi client Connect vao server.
				//Nhu vay moi client se doc lap nhau, khong phai cho doi tung client xu ly rieng
				//cout << cnt;
				threadStatus = CreateThread(NULL, 0, function_cal, hConnected, 0, &threadID);

			} while (1);
		}
	}
	else
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: GetModuleHandle failed\n"));
		nRetCode = 1;
	}

	return nRetCode;
}

